// Здесь мы подключаем все файлы js

///= libs/popper.js
​
///= bootstrap/util.js
///= bootstrap/collapse.js
///= bootstrap/dropdown.js
​///= bootstrap/alert.js
///= bootstrap/button.js
///= bootstrap/carousel.js
///= bootstrap/modal.js
///= bootstrap/popover.js
///= bootstrap/scrollspy.js
///= bootstrap/tab.js
///= bootstrap/toast.js
///= bootstrap/tooltip.js

//= scripts.js